/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package com.ktech.connection;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.TreeSet;

/**
 *
 * @author santosh
 */
public class CodeBuilder {

    /**
     * @param args the command line arguments
     */
    private static Statement stmt;
    private static ResultSet rs;
    private static String db;
    private static String domainPackageName = "cc/altius/model";
    private static String mapperPackageName = "cc/altius/model/mapper";
    private static String TABLE_STR = "TABLE";
    private static String COLUMN_STR = "COLUMN";
    private static String METHOD_STR = "METHOD";

    public static void main(String[] args) {
        try {
            // TODO code application logic here
            System.out.println("Initialize database connection...");
            DBConnection connection = new DBConnection();

            //STEP 4: Execute a query
            System.out.println("Creating statement...");
            stmt = connection.getConnection().createStatement();

            db = connection.getDBName();
            System.out.println("Connected to database: " + db);

            String sql = "SELECT TABLE_NAME FROM INFORMATION_SCHEMA.TABLES WHERE TABLE_SCHEMA='" + db + "'";
            rs = stmt.executeQuery(sql);

            System.out.println("Fetch table names...");
            List<String> tables = new ArrayList<String>();
            while (rs.next()) {
                tables.add(rs.getString("TABLE_NAME"));
            }

            buildColumnSchema(tables);

            rs.close();
            stmt.close();
            connection.getConnection().close();
        } catch (SQLException sqle) {
            sqle.printStackTrace();
        }
    }

    public static void buildColumnSchema(List<String> tables) {
        for (String table : tables) {
            List<CodeBuilder.ColumnSchema> columnSchemas = new ArrayList<CodeBuilder.ColumnSchema>();
            try {
                String sql = "SELECT DISTINCT c.COLUMN_NAME, c.DATA_TYPE, c.COLUMN_KEY, k.REFERENCED_TABLE_NAME, k.`REFERENCED_COLUMN_NAME` FROM INFORMATION_SCHEMA.`COLUMNS` AS c"
                        //+ " LEFT JOIN INFORMATION_SCHEMA.KEY_COLUMN_USAGE AS k ON c.COLUMN_NAME = k.REFERENCED_COLUMN_NAME"
                        + " LEFT JOIN INFORMATION_SCHEMA.KEY_COLUMN_USAGE AS k ON c.COLUMN_NAME = k.`COLUMN_NAME` AND c.`TABLE_NAME`=k.`TABLE_NAME`"
                        + " LEFT JOIN INFORMATION_SCHEMA.`TABLE_CONSTRAINTS` t ON k.`CONSTRAINT_NAME`=t.`CONSTRAINT_NAME`"
                        + " WHERE c.TABLE_SCHEMA='" + db + "' AND c.TABLE_NAME='" + table + "'  AND (t.`CONSTRAINT_TYPE` !='UNIQUE' || t.`CONSTRAINT_TYPE` IS NULL)";
                rs = stmt.executeQuery(sql);

                while (rs.next()) {
                    CodeBuilder.ColumnSchema cs = new CodeBuilder.ColumnSchema(rs.getString("COLUMN_NAME"), rs.getString("DATA_TYPE"), rs.getString("COLUMN_KEY"), rs.getString("REFERENCED_TABLE_NAME"), rs.getString("REFERENCED_COLUMN_NAME"));
                    columnSchemas.add(cs);
                }
            } catch (SQLException sqle) {
                sqle.printStackTrace();
            }

            buildClass(table, columnSchemas);
            buildMapper(table, columnSchemas);
        }
    }

    public static void buildClass(String tableName, List<CodeBuilder.ColumnSchema> columnNames) {
        try {
            //create package in current project
            String className = getCamel(tableName, TABLE_STR);
            String fileLocation = new java.io.File(".").getCanonicalPath() + "/src/" + domainPackageName;
            new File(fileLocation).mkdir();

            //create java files in recently created package
            File file = new File(fileLocation + "/" + className + ".java");
            file.createNewFile();

            //Write into current file
            FileWriter fw = new FileWriter(file.getAbsoluteFile());
            BufferedWriter bw = new BufferedWriter(fw);
            bw.write(buildClassContent(className, columnNames));
            bw.close();
            fw.close();

        } catch (IOException ioe) {
            ioe.printStackTrace();
        }
    }

    public static String buildClassContent(String className, List<CodeBuilder.ColumnSchema> columnNames) {
        StringBuilder sb = new StringBuilder();
        sb.append("/*\n").append("*Author: Santosh").append("\n*Created On: ").append(new SimpleDateFormat("yyyyMMdd").format(new Date())).append("\n*/\n");

        sb.append("package ").append(domainPackageName.replace("/", ".")).append(";");
        sb.append("\n");

        boolean dateNotImport = true;
//        TreeSet<String> uniqStr = new TreeSet<String>();
        for (CodeBuilder.ColumnSchema cs : columnNames) {

//            if (cs.getReferenceTableName() != null && cs.getColumnKey().equals("MUL")) {
//                uniqStr.add(cs.getReferenceTableName());
//            }

            if ((cs.getDataType().trim().equals("date")) || (cs.getDataType().trim().equals("datetime")) || (cs.getDataType().trim().equals("timestamp")) || (cs.getDataType().trim().equals("time"))) {
                if (dateNotImport) {
                    sb.append("\nimport java.util.Date;");
                    dateNotImport = false;
                }
            }
        }
//        for (String str : uniqStr) {
//            sb.append("\nimport ").append(domainPackageName.replace("/", ".")).append(".").append(getCamel(str, TABLE_STR)).append(";");
//        }

        sb.append("\n\npublic class ").append(className).append("{").append("\n");
        //create variables
        for (CodeBuilder.ColumnSchema cs : columnNames) {
            sb.append("\n    private");
            sb.append(" ");

            if (getJavaBasedDataType(cs).equals("byte")) {
                sb.append(getJavaBasedDataType(cs)).append("[]");
            } else if (getJavaBasedDataType(cs).equals("string")) {
                sb.append(getCamel(getJavaBasedDataType(cs), METHOD_STR));
            } else {
                sb.append(getJavaBasedDataType(cs));
            }

            sb.append(" ").append(getCamel(getJavaBasedColumnName(cs), COLUMN_STR));
            sb.append(";");
        }

        //create constructure
        sb.append("\n\n");
        sb.append("    public ").append(className).append("(){");
        sb.append("}");
        sb.append("\n\n");
        sb.append("    public ").append(className).append("(");
        int comma = 0;
        for (CodeBuilder.ColumnSchema cs : columnNames) {
            if (comma != 0) {
                sb.append(", ");
            }

            if (getJavaBasedDataType(cs).equals("byte")) {
                sb.append(getJavaBasedDataType(cs)).append("[]");
            } else if (getJavaBasedDataType(cs).equals("string")) {
                sb.append(getCamel(getJavaBasedDataType(cs), METHOD_STR));
            } else {
                sb.append(getJavaBasedDataType(cs));
            }

            sb.append(" ").append(getCamel(getJavaBasedColumnName(cs), COLUMN_STR));
            comma++;
        }
        sb.append("){\n");
        int newline = 0;
        for (CodeBuilder.ColumnSchema cs : columnNames) {
            if (newline != 0) {
                sb.append("\n");
            }
            sb.append("        this.");
            sb.append(getCamel(getJavaBasedColumnName(cs), COLUMN_STR));
            sb.append("=");
            sb.append(getCamel(getJavaBasedColumnName(cs), COLUMN_STR));
            sb.append(";");
            newline++;
        }
        sb.append("\n    }");

        //create setter methods
        for (CodeBuilder.ColumnSchema cs : columnNames) {
            sb.append("\n\n    ").append("public");
            sb.append(" ").append("void").append(" ");
            sb.append("set");
            sb.append(getCamel(getJavaBasedColumnName(cs), METHOD_STR));
            sb.append("(");
            if (getJavaBasedDataType(cs).equals("byte")) {
                sb.append(getJavaBasedDataType(cs)).append("[]");
            } else if (getJavaBasedDataType(cs).equals("string")) {
                sb.append(getCamel(getJavaBasedDataType(cs), METHOD_STR));
            } else {
                sb.append(getJavaBasedDataType(cs));
            }
            sb.append(" ");
            sb.append(getCamel(getJavaBasedColumnName(cs), COLUMN_STR));
            sb.append("){\n");
            sb.append("        this.");
            sb.append(getCamel(getJavaBasedColumnName(cs), COLUMN_STR));
            sb.append("=");
            sb.append(getCamel(getJavaBasedColumnName(cs), COLUMN_STR));
            sb.append(";");
            sb.append("\n    }");
        }
        sb.append("\n");

        //create getter methods
        for (CodeBuilder.ColumnSchema cs : columnNames) {
            sb.append("\n\n    ").append("public");
            sb.append(" ");
            if (getJavaBasedDataType(cs).equals("byte")) {
                sb.append(getJavaBasedDataType(cs)).append("[]");
            } else if (getJavaBasedDataType(cs).equals("string")) {
                sb.append(getCamel(getJavaBasedDataType(cs), METHOD_STR));
            } else {
                sb.append(getJavaBasedDataType(cs));
            }
            sb.append(" ");
            if (getJavaBasedDataType(cs).equals("boolean")) {
                sb.append("is");
            } else {
                sb.append("get");
            }
            sb.append(getCamel(getJavaBasedColumnName(cs), METHOD_STR));
            sb.append("(){\n");
            sb.append("        return this.");
            sb.append(getCamel(getJavaBasedColumnName(cs), COLUMN_STR));
            sb.append(";");
            sb.append("\n    }");
        }
        sb.append("\n");
        sb.append("\n}");

        return sb.toString();
    }

    public static String getJavaBasedDataType(CodeBuilder.ColumnSchema cs) {
        StringBuilder builder = new StringBuilder();
        if (cs.getReferenceTableName() != null && cs.getColumnKey().equals("MUL")) {
            builder.append(getCamel(cs.getReferenceTableName(), TABLE_STR));
        } else {

            if ((cs.getDataType().trim().equals("binary")) || (cs.getDataType().trim().equals("blob")) || (cs.getDataType().trim().equals("longblob")) || (cs.getDataType().trim().equals("mediumblob")) || (cs.getDataType().trim().equals("tinyblob")) || (cs.getDataType().trim().equals("varbinary"))) {
                builder.append("byte");
            } else if ((cs.getDataType().trim().equals("bit")) || (cs.getDataType().trim().equals("bool")) || (cs.getDataType().trim().equals("boolean")) || (cs.getDataType().trim().equals("tinyint"))) {
                builder.append("boolean");
            } else if ((cs.getDataType().trim().equals("date")) || (cs.getDataType().trim().equals("datetime")) || (cs.getDataType().trim().equals("timestamp")) || (cs.getDataType().trim().equals("time"))) {
                builder.append("Date");
            } else if ((cs.getDataType().trim().equals("enum")) || (cs.getDataType().trim().equals("longtext")) || (cs.getDataType().trim().equals("mediumtext")) || (cs.getDataType().trim().equals("set")) || (cs.getDataType().trim().equals("text")) || (cs.getDataType().trim().equals("varchar")) || (cs.getDataType().trim().equals("tinytext"))) {
                builder.append("String");
            } else if ((cs.getDataType().trim().equals("float"))) {
                builder.append("float");
            } else if ((cs.getDataType().trim().equals("int")) || (cs.getDataType().trim().equals("mediumint")) || (cs.getDataType().trim().equals("smallint")) || (cs.getDataType().trim().equals("numeric"))) {
                builder.append("int");
            } else if ((cs.getDataType().trim().equals("year"))) {
                builder.append("short");
            } else if ((cs.getDataType().trim().equals("double")) || (cs.getDataType().trim().equals("decimal")) || (cs.getDataType().trim().equals("real"))) {
                builder.append("double");
            } else if ((cs.getDataType().trim().equals("char"))) {
                builder.append("char");
            } else if ((cs.getDataType().trim().equals("bigint"))) {
                builder.append("long");
            } else {
                builder.append(cs.getDataType().trim());
            }
        }
        return builder.toString();
    }

    public static String getJavaBasedColumnName(CodeBuilder.ColumnSchema cs) {
        if (cs.getReferenceTableName() != null && cs.getColumnKey().equals("MUL") && cs.getColumnName().contains("_ID")) {
            return cs.getReferenceTableName();
        } else {
            return cs.getColumnName();
        }
    }

    public static String getCamel(String query, String strType) {
        StringBuilder builder = new StringBuilder();
        String[] strArr = query.toLowerCase().split("_");
        int first = 0;
        for (String str : strArr) {
            if (str.equals("")) {
                continue;
            }
            if (first == 0) {
                if (strType.equals(TABLE_STR)) {
                    builder.append(Character.toUpperCase(str.charAt(0))).append(str.substring(1));
                } else if (strType.equals(COLUMN_STR)) {
                    builder.append(str.toLowerCase());
                } else if (strType.equals(METHOD_STR)) {
                    builder.append(Character.toUpperCase(str.charAt(0))).append(str.substring(1));
                } else {
                    builder.append(str.toLowerCase());
                }
            } else {
                builder.append(Character.toUpperCase(str.charAt(0))).append(str.substring(1));
            }
            first++;
        }

        return builder.toString();
    }

    static class ColumnSchema {

        private String columnName;
        private String dataType;
        private String columnKey;
        private String referenceTableName;
        private String referenceColumnName;

        public ColumnSchema() {
        }

        public ColumnSchema(String columnName, String dataType, String columnKey, String referenceTableName, String referenceColumnName) {
            this.columnName = columnName;
            this.dataType = dataType;
            this.columnKey = columnKey;
            this.referenceTableName = referenceTableName;
            this.referenceColumnName = referenceColumnName;
        }

        public String getColumnName() {
            return columnName;
        }

        public String getDataType() {
            return dataType;
        }

        public String getColumnKey() {
            return columnKey;
        }

        public String getReferenceTableName() {
            return referenceTableName;
        }

        public String getReferenceColumnName() {
            return referenceColumnName;
        }
    }

    public static void buildMapper(String tableName, List<CodeBuilder.ColumnSchema> columnNames) {
        try {
            //create package in current project
            String className = getCamel(tableName, TABLE_STR);
            String fileLocation = new java.io.File(".").getCanonicalPath() + "/src/" + mapperPackageName;
            new File(fileLocation).mkdir();

            //create java files in recently created package
            File file = new File(fileLocation + "/" + className + "RowMapper.java");
            file.createNewFile();

            //Write into current file
            FileWriter fw = new FileWriter(file.getAbsoluteFile());
            BufferedWriter bw = new BufferedWriter(fw);
            bw.write(buildMapperContent(className, columnNames));
            bw.close();
            fw.close();

        } catch (IOException ioe) {
            ioe.printStackTrace();
        }
    }

    public static String buildMapperContent(String className, List<CodeBuilder.ColumnSchema> columnNames) {
        StringBuilder sb = new StringBuilder();
        sb.append("/*\n").append("*Author: Santosh").append("\n*Created On: ").append(new SimpleDateFormat("yyyyMMdd").format(new Date())).append("\n*/\n");

        sb.append("package ").append(mapperPackageName.replace("/", ".")).append(";");
        sb.append("\n");
        sb.append("\nimport ").append(domainPackageName.replace("/", ".")).append(".").append(className).append(";");

        //boolean dateNotImport = true;
        TreeSet<String> uniqStr = new TreeSet<String>();
        for (CodeBuilder.ColumnSchema cs : columnNames) {

            if (cs.getReferenceTableName() != null && cs.getColumnKey().equals("MUL")) {
                uniqStr.add(cs.getReferenceTableName());
            }

//            if ((cs.getDataType().trim().equals("date")) || (cs.getDataType().trim().equals("datetime")) || (cs.getDataType().trim().equals("timestamp")) || (cs.getDataType().trim().equals("time"))) {
//                if (dateNotImport) {
//                    sb.append("\nimport java.util.Date;");
//                    dateNotImport = false;
//                }
//            }
        }

        for (String str : uniqStr) {
            sb.append("\nimport ").append(domainPackageName.replace("/", ".")).append(".").append(getCamel(str, TABLE_STR)).append(";");
        }

        sb.append("\nimport java.sql.ResultSet;");
        sb.append("\nimport java.sql.SQLException;");
        sb.append("\nimport org.springframework.jdbc.core.RowMapper;");

        sb.append("\n\npublic class ").append(className).append("RowMapper").append(" implements RowMapper<").append(className).append("> {").append("\n");

        sb.append("\n    @Override");
        sb.append("\n    public ").append(className).append(" mapRow(ResultSet rs, int i) throws SQLException {");

        sb.append("\n        ").append(className).append(" ").append(getCamel(className, COLUMN_STR)).append(" = ").append("new ").append(className).append("();");

        uniqStr.clear();
        for (CodeBuilder.ColumnSchema cs : columnNames) {


            if (cs.getReferenceTableName() != null && cs.getColumnKey().equals("MUL")) {
                sb.append("\n");
                String subClassName = getCamel(cs.getReferenceTableName(), TABLE_STR);

                String subDataType;
                if ((cs.getDataType().trim().equals("binary")) || (cs.getDataType().trim().equals("blob")) || (cs.getDataType().trim().equals("longblob")) || (cs.getDataType().trim().equals("mediumblob")) || (cs.getDataType().trim().equals("tinyblob")) || (cs.getDataType().trim().equals("varbinary"))) {
                    subDataType = "bytes";
                } else if ((cs.getDataType().trim().equals("bit")) || (cs.getDataType().trim().equals("bool")) || (cs.getDataType().trim().equals("boolean")) || (cs.getDataType().trim().equals("tinyint"))) {
                    subDataType = "boolean";
                } else if ((cs.getDataType().trim().equals("date")) || (cs.getDataType().trim().equals("datetime")) || (cs.getDataType().trim().equals("timestamp")) || (cs.getDataType().trim().equals("time"))) {
                    subDataType = "Date";
                } else if ((cs.getDataType().trim().equals("enum")) || (cs.getDataType().trim().equals("longtext")) || (cs.getDataType().trim().equals("mediumtext")) || (cs.getDataType().trim().equals("set")) || (cs.getDataType().trim().equals("text")) || (cs.getDataType().trim().equals("varchar")) || (cs.getDataType().trim().equals("tinytext"))) {
                    subDataType = "String";
                } else if ((cs.getDataType().trim().equals("float"))) {
                    subDataType = "float";
                } else if ((cs.getDataType().trim().equals("int")) || (cs.getDataType().trim().equals("mediumint")) || (cs.getDataType().trim().equals("smallint")) || (cs.getDataType().trim().equals("numeric"))) {
                    subDataType = "int";
                } else if ((cs.getDataType().trim().equals("year"))) {
                    subDataType = "short";
                } else if ((cs.getDataType().trim().equals("double")) || (cs.getDataType().trim().equals("decimal")) || (cs.getDataType().trim().equals("real"))) {
                    subDataType = "double";
                } else if ((cs.getDataType().trim().equals("char"))) {
                    subDataType = "char";
                } else if ((cs.getDataType().trim().equals("bigint"))) {
                    subDataType = "long";
                } else {
                    subDataType = cs.getDataType().trim();
                }

                sb.append("\n        ");
                if (!uniqStr.contains(subClassName)) {
                    sb.append(subClassName).append(" ");
                }
                sb.append(getCamel(subClassName, COLUMN_STR)).append(" = ").append("new ").append(subClassName).append("();");
                sb.append("\n        ").append(getCamel(subClassName, COLUMN_STR)).append(".set").append(getCamel(cs.getReferenceColumnName(), METHOD_STR)).append("(");
                sb.append("rs.get").append(getCamel(subDataType, METHOD_STR)).append("(\"").append(cs.getColumnName().toUpperCase()).append("\"").append(")");
                sb.append(");");
                sb.append("\n        ").append(getCamel(className, COLUMN_STR)).append(".set").append(getCamel(getJavaBasedColumnName(cs), METHOD_STR)).append("(").append(getCamel(subClassName, COLUMN_STR)).append(");");
                sb.append("\n");

                uniqStr.add(subClassName);
            } else {
                sb.append("\n        ").append(getCamel(className, COLUMN_STR)).append(".set").append(getCamel(getJavaBasedColumnName(cs), METHOD_STR)).append("(");
                sb.append("rs.get");
                if (getJavaBasedDataType(cs).equals("byte")) {
                    sb.append(getCamel(getJavaBasedDataType(cs) + "s", METHOD_STR));
                } else {
                    sb.append(getCamel(getJavaBasedDataType(cs), METHOD_STR));
                }
                sb.append("(\"").append(cs.getColumnName().toUpperCase()).append("\")");
                sb.append(");");
            }
        }
        sb.append("\n        return ").append(getCamel(className, COLUMN_STR)).append(";");
        sb.append("\n    }");
        sb.append("\n}");

        return sb.toString();
    }
}
