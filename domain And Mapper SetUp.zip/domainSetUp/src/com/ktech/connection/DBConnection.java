/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package com.ktech.connection;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

/**
 *
 * @author santosh
 */
public class DBConnection {
    // JDBC driver name and database URL

    private static String JDBC_DRIVER = "com.mysql.jdbc.Driver";
    private static String DB_URL = "jdbc:mysql://localhost/mydatabase";
    private static String USER = "databaseUser";
    private static String PASS = "databasePassword";
    private Connection conn = null;

    public DBConnection() {
        try {
            //STEP 2: Register JDBC driver
            Class.forName(JDBC_DRIVER);

            //STEP 3: Open a connection
            System.out.println("Connecting to database...");
            conn = DriverManager.getConnection(DB_URL, USER, PASS);

        } catch (ClassNotFoundException | SQLException cnfe) {
            cnfe.printStackTrace();
        }
    }

    public Connection getConnection() {
        return conn;
    }

    public String getDBName() {
        String[] str = DB_URL.split("/");
        return str[3];
    }

}
